<?php
$themeName = 'eLavenn';

$themeFolder = 'elavenn';

$themeAuthor = 'Teja Sundeep';

$themeAuthorUrl = 'mailto:tsreddykarri94@gmail.com';

$themeVirsion = '1.2';

$themeImg = $themeFolder . '/themeLogo.png';
?>